<?php

	if(isset($_GET['para']))
	{
		if($_GET['para']==1)
		{
			echo "<h2 align='center'><BR>Aaila ! End Of Question Set. Well Played.</h2><BR>
			<p align='center'>Please Logout to save changes.</p>";		
		}
	}
?>